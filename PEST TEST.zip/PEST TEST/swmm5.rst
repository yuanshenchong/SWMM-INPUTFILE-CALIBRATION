start_iteration 1  1  svd_base_par
termination_info_1 30 0 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3 
parameter_file_save_started swmm5.parb
parameter_file_save_finished swmm5.parb
jacobian_model_runs_built
